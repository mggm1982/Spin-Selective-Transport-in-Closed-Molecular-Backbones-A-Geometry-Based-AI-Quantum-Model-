CISS PROJECT -- DATASET README
==============================
Companion to: CISS_Research_Submission_RunAll(3).ipynb

PURPOSE
-------
This note explains the research dataset's origin, files, and use in the
submitted code. The results reported in the paper were computed from the
verified original dataset, not the notebook's optional smaller generator.

1. ORIGINAL DATASET GENERATION
------------------------------
The original simulation workflow is preserved in
CISS_Generalized_Simulator(2).ipynb. Its Cell 57D creates the fixed
experiment manifest, Cell 59 runs the checkpointed NEGF calculations,
and Cell 61A exports the main experiment as ML-ready arrays.

The model uses 60-site closed backbones, geometry-dependent spin-orbit
hopping, nonmagnetic contacts, and coherent or Büttiker-probe transport.
The experiment covers 180 independent geometry groups (60 planar loops,
60 nonplanar unknots, 60 trefoils), with mirror-related geometries.

The original campaign comprises 11,424 jobs: 6,480 main, 3,780 anchor,
540 control, 612 challenge, and 12 dense-stress jobs. The MAIN experiment
produces 25,920 per-drain observations. One job can produce several rows
because each output drain has a separate transmission and polarization.

The original raw simulation results are stored in ciss_transport_v2_v1/.
The condensed, verified MAIN ML export is in ciss_v2_ml_input_v1/.

2. DATAFILES REQUIRED TO RUN THE REPORTED ANALYSIS
--------------------------------------------------
Place the following files under the notebook's WORKING DIRECTORY
(shown by 'Working directory:' in Code Cell 1):

  CISS_Research_Submission_RunAll(3).ipynb
  CISS_Dataset_README_Submission.txt
  ciss_v2_ml_input_v1/
      main_per_drain_arrays.npz
      main_per_drain_metadata.csv
      schema.json

* main_per_drain_arrays.npz: X (427 raw inputs), Y (seven NEGF outputs:
  T, Sx, Sy, Sz, Px, Py, Pz), and a P_usable mask.
* main_per_drain_metadata.csv: geometry ID, geometry family, split,
  reflection, job ID, source and target drain, drain count and probe regime.
* schema.json: export identity, counts, feature/target description, and
  SHA-256 hashes for the two data files.

These are the ACTUAL original-data files. Merely providing this README
or the notebook does not substitute for the dataset.

3. HOW THE FINAL NOTEBOOK LOADS AND USES THE DATA
------------------------------------------------
Code Cells 13-14 verify the original export's schema, SHA-256 checksums,
25,920 rows, 180 geometry groups, and expected input dimensions.
Code Cell 18 chooses the data source in this order:
  (1) Verified ciss_v2_ml_input_v1/         -> original research export
  (2) Verified ciss_runall_dataset_v1/     -> separate saved rerun
  (3) Neither available                    -> create a new separate rerun

Code Cells 19-21 inspect the data and export geometry-group-disjoint
train/validation/test files. Only one reflection is used in ML splits:
9,072 training, 1,944 validation, and 1,944 test rows, across 126/27/27
geometry groups. Code Cells 22-25 convert the raw inputs into 185
physics-informed features and train/validate the screening model.
Code Cells 26-29 save the model and a checksum-protected prediction
ranking, then evaluate the held-out test labels. Code Cells 30-33
summarize high-polarization physics and verify the saved results.

With the original data selected, the notebook creates or verifies:
  ciss_submission_splits_frozen_v2/
    partition_manifest.json
    training data/, validation data/, testing data/
    (each has features.npz, labels_sealed.npz and metadata.csv)

  ciss_submission_screening_frozen_v2/
    protocol.json, screening_model.joblib, locked_test_ranking.csv,
    prediction_lock.json, final_test_report.json

These derivative directories should also be submitted to preserve the
exact documented ML ranking and evaluation. Files with unexpected
hashes or incompatible experiment settings are not silently replaced.

4. IMPORTANT: OPTIONAL FALLBACK GENERATOR
-----------------------------------------
If the original export is absent, Code Cells 15-17 and 18 can create a
separate dataset in ciss_runall_dataset_v1/ using new geometry recipes
and sampled operating points. At standard settings it has 180 geometry
groups, 12 operating points/group, two mirror realizations, and 8,640
per-drain observations. This uses the same general NEGF physics model,
but NOT the original experiment's manifest or sampling schedule.

It is a useful workflow demonstration, not an exact reproduction of the
original 11,424-job production experiment. Its results should NOT be
presented as the results of the paper. A change to its sample count alone
would not make it equivalent to the original dataset.

5. REPRODUCTION CHECK AND REPORTED RESULTS
------------------------------------------
Run the notebook cells in order with the original data folder present.
Code Cell 18 should print:
  Verified cached dataset: ciss_v2_ml_input_v1
  Origin: frozen_v2

In the saved original-data execution, the notebook reports:
  25,920 main rows; 25,712 usable at T >= 0.01;
  202 rows with |P| >= 90%; maximum |P| = 99.9708%;
  1,836 active held-out candidates; 63 hits among 184 shortlisted;
  34.24% top-10% precision; 3.29x screening enrichment;
  ROC-AUC = 0.859.

The cleaned notebook reproduces analysis from the saved research export.
It does NOT itself recreate the exact full original raw campaign when the
saved export is missing. For deeper provenance or full regeneration,
include the original simulator, its support code, original experiment
manifest (ciss_v2_experiment_design_v1.json), and raw output archive
(ciss_transport_v2_v1/) if those are being provided.

SUBMISSION RECOMMENDATION
-------------------------
At minimum submit: final notebook, original ciss_v2_ml_input_v1/ folder,
this README, paper, and presentation/video as required. Also include the
saved splits and screening folders for exact research-result provenance.

End.
